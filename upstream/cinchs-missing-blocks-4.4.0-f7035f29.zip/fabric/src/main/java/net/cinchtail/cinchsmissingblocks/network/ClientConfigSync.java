package net.cinchtail.cinchsmissingblocks.network;

import net.cinchtail.cinchsmissingblocks.config.ModConfigs;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.text.Text;

public class ClientConfigSync {

    public static void register() {

        ClientPlayNetworking.registerGlobalReceiver(
                ConfigSyncPayload.ID,
                (payload, context) -> {

                    MinecraftClient client = MinecraftClient.getInstance();
                    boolean serverWantsTuffPillars = payload.enableTuffBrickPillar();
                    boolean clientValue = ModConfigs.enableTuffBrickPillar;

                    if (serverWantsTuffPillars != clientValue) {

                        client.execute(() -> {

                            if (client.player == null || client.world == null) {
                                return;
                            }

                            ClientPlayNetworkHandler handler = client.getNetworkHandler();
                            if (handler != null) {
                                handler.getConnection().disconnect(
                                        Text.literal(
                                                "Your Cinch's Missing Blocks config does not match the server.\n\n" +
                                                        "Server requires: \"enableTuffBrickPillar\": " + serverWantsTuffPillars + "\n" +
                                                        "Your config: \"enableTuffBrickPillar\": " + clientValue + "\n\n" +
                                                        "Please update your config and reconnect.\n\n" +
                                                        "Your config is located in .minecraft\\config\\cinchsmissingblocks.json."
                                        )
                                );
                            }
                        });
                    }
                }
        );
    }
}