package net.cinchtail.cinchsmissingblocks.datagen;

import net.cinchtail.cinchsmissingblocks.block.ModBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.enums.SlabType;
import net.minecraft.item.Items;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.condition.BlockStatePropertyLootCondition;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.function.ExplosionDecayLootFunction;
import net.minecraft.loot.function.SetCountLootFunction;
import net.minecraft.loot.provider.number.ConstantLootNumberProvider;
import net.minecraft.registry.RegistryWrapper;

import java.util.concurrent.CompletableFuture;

public class ModLootTableProvider extends FabricBlockLootTableProvider {
    public ModLootTableProvider(FabricDataOutput dataOutput, CompletableFuture<RegistryWrapper.WrapperLookup> registryLookup) {
        super(dataOutput, registryLookup);
    }

    @Override
    public void generate() {

        addDrop(ModBlocks.CALCITE_STAIRS);
        addDrop(ModBlocks.CALCITE_SLAB, slabDrops(ModBlocks.CALCITE_SLAB));
        addDrop(ModBlocks.CALCITE_WALL);
        addDrop(ModBlocks.POLISHED_CALCITE);
        addDrop(ModBlocks.POLISHED_CALCITE_STAIRS);
        addDrop(ModBlocks.POLISHED_CALCITE_SLAB, slabDrops(ModBlocks.POLISHED_CALCITE_SLAB));
        addDrop(ModBlocks.POLISHED_CALCITE_WALL);
        addDrop(ModBlocks.CALCITE_BRICKS);
        addDrop(ModBlocks.CALCITE_BRICK_STAIRS);
        addDrop(ModBlocks.CALCITE_BRICK_SLAB, slabDrops(ModBlocks.CALCITE_BRICK_SLAB));
        addDrop(ModBlocks.CALCITE_BRICK_WALL);
        addDrop(ModBlocks.CRACKED_CALCITE_BRICKS);
        addDrop(ModBlocks.CRACKED_CALCITE_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_CALCITE_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_CALCITE_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_CALCITE_BRICK_WALL);
        addDrop(ModBlocks.MOSSY_CALCITE_BRICKS);
        addDrop(ModBlocks.MOSSY_CALCITE_BRICK_STAIRS);
        addDrop(ModBlocks.MOSSY_CALCITE_BRICK_SLAB, slabDrops(ModBlocks.MOSSY_CALCITE_BRICK_SLAB));
        addDrop(ModBlocks.MOSSY_CALCITE_BRICK_WALL);
        addDrop(ModBlocks.CHISELED_CALCITE_BRICKS);
        addDrop(ModBlocks.CALCITE_BRICK_PILLAR);

        addDrop(ModBlocks.DRIPSTONE_STAIRS);
        addDrop(ModBlocks.DRIPSTONE_SLAB, slabDrops(ModBlocks.DRIPSTONE_SLAB));
        addDrop(ModBlocks.DRIPSTONE_WALL);
        addDrop(ModBlocks.POLISHED_DRIPSTONE);
        addDrop(ModBlocks.POLISHED_DRIPSTONE_STAIRS);
        addDrop(ModBlocks.POLISHED_DRIPSTONE_SLAB, slabDrops(ModBlocks.POLISHED_DRIPSTONE_SLAB));
        addDrop(ModBlocks.POLISHED_DRIPSTONE_WALL);
        addDrop(ModBlocks.DRIPSTONE_BRICKS);
        addDrop(ModBlocks.DRIPSTONE_BRICK_STAIRS);
        addDrop(ModBlocks.DRIPSTONE_BRICK_SLAB, slabDrops(ModBlocks.DRIPSTONE_BRICK_SLAB));
        addDrop(ModBlocks.DRIPSTONE_BRICK_WALL);
        addDrop(ModBlocks.CRACKED_DRIPSTONE_BRICKS);
        addDrop(ModBlocks.CRACKED_DRIPSTONE_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_DRIPSTONE_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_DRIPSTONE_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_DRIPSTONE_BRICK_WALL);
        addDrop(ModBlocks.MOSSY_DRIPSTONE_BRICKS);
        addDrop(ModBlocks.MOSSY_DRIPSTONE_BRICK_STAIRS);
        addDrop(ModBlocks.MOSSY_DRIPSTONE_BRICK_SLAB, slabDrops(ModBlocks.MOSSY_DRIPSTONE_BRICK_SLAB));
        addDrop(ModBlocks.MOSSY_DRIPSTONE_BRICK_WALL);
        addDrop(ModBlocks.CHISELED_DRIPSTONE_BRICKS);
        addDrop(ModBlocks.DRIPSTONE_BRICK_PILLAR);

        addDrop(ModBlocks.CRACKED_TUFF_BRICKS);
        addDrop(ModBlocks.CRACKED_TUFF_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_TUFF_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_TUFF_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_TUFF_BRICK_WALL);
        addDrop(ModBlocks.MOSSY_TUFF_BRICKS);
        addDrop(ModBlocks.MOSSY_TUFF_BRICK_STAIRS);
        addDrop(ModBlocks.MOSSY_TUFF_BRICK_SLAB, slabDrops(ModBlocks.MOSSY_TUFF_BRICK_SLAB));
        addDrop(ModBlocks.MOSSY_TUFF_BRICK_WALL);

        addDrop(ModBlocks.POLISHED_ANDESITE_WALL);
        addDrop(ModBlocks.ANDESITE_BRICKS);
        addDrop(ModBlocks.ANDESITE_BRICK_STAIRS);
        addDrop(ModBlocks.ANDESITE_BRICK_SLAB, slabDrops(ModBlocks.ANDESITE_BRICK_SLAB));
        addDrop(ModBlocks.ANDESITE_BRICK_WALL);
        addDrop(ModBlocks.CRACKED_ANDESITE_BRICKS);
        addDrop(ModBlocks.CRACKED_ANDESITE_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_ANDESITE_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_ANDESITE_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_ANDESITE_BRICK_WALL);
        addDrop(ModBlocks.MOSSY_ANDESITE_BRICKS);
        addDrop(ModBlocks.MOSSY_ANDESITE_BRICK_STAIRS);
        addDrop(ModBlocks.MOSSY_ANDESITE_BRICK_SLAB, slabDrops(ModBlocks.MOSSY_ANDESITE_BRICK_SLAB));
        addDrop(ModBlocks.MOSSY_ANDESITE_BRICK_WALL);
        addDrop(ModBlocks.CHISELED_ANDESITE_BRICKS);
        addDrop(ModBlocks.ANDESITE_BRICK_PILLAR);

        addDrop(ModBlocks.POLISHED_GRANITE_WALL);
        addDrop(ModBlocks.GRANITE_BRICKS);
        addDrop(ModBlocks.GRANITE_BRICK_STAIRS);
        addDrop(ModBlocks.GRANITE_BRICK_SLAB, slabDrops(ModBlocks.GRANITE_BRICK_SLAB));
        addDrop(ModBlocks.GRANITE_BRICK_WALL);
        addDrop(ModBlocks.CRACKED_GRANITE_BRICKS);
        addDrop(ModBlocks.CRACKED_GRANITE_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_GRANITE_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_GRANITE_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_GRANITE_BRICK_WALL);
        addDrop(ModBlocks.MOSSY_GRANITE_BRICKS);
        addDrop(ModBlocks.MOSSY_GRANITE_BRICK_STAIRS);
        addDrop(ModBlocks.MOSSY_GRANITE_BRICK_SLAB, slabDrops(ModBlocks.MOSSY_GRANITE_BRICK_SLAB));
        addDrop(ModBlocks.MOSSY_GRANITE_BRICK_WALL);
        addDrop(ModBlocks.CHISELED_GRANITE_BRICKS);
        addDrop(ModBlocks.GRANITE_BRICK_PILLAR);

        addDrop(ModBlocks.POLISHED_DIORITE_WALL);
        addDrop(ModBlocks.DIORITE_BRICKS);
        addDrop(ModBlocks.DIORITE_BRICK_STAIRS);
        addDrop(ModBlocks.DIORITE_BRICK_SLAB, slabDrops(ModBlocks.DIORITE_BRICK_SLAB));
        addDrop(ModBlocks.DIORITE_BRICK_WALL);
        addDrop(ModBlocks.CRACKED_DIORITE_BRICKS);
        addDrop(ModBlocks.CRACKED_DIORITE_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_DIORITE_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_DIORITE_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_DIORITE_BRICK_WALL);
        addDrop(ModBlocks.MOSSY_DIORITE_BRICKS);
        addDrop(ModBlocks.MOSSY_DIORITE_BRICK_STAIRS);
        addDrop(ModBlocks.MOSSY_DIORITE_BRICK_SLAB, slabDrops(ModBlocks.MOSSY_DIORITE_BRICK_SLAB));
        addDrop(ModBlocks.MOSSY_DIORITE_BRICK_WALL);
        addDrop(ModBlocks.CHISELED_DIORITE_BRICKS);
        addDrop(ModBlocks.DIORITE_BRICK_PILLAR);

        addDrop(ModBlocks.QUARTZ_WALL);
        addDrop(ModBlocks.SMOOTH_QUARTZ_WALL);
        addDrop(ModBlocks.QUARTZ_BRICK_STAIRS);
        addDrop(ModBlocks.QUARTZ_BRICK_SLAB, slabDrops(ModBlocks.QUARTZ_BRICK_SLAB));
        addDrop(ModBlocks.QUARTZ_BRICK_WALL);
        addDrop(ModBlocks.CRACKED_QUARTZ_BRICKS);
        addDrop(ModBlocks.CRACKED_QUARTZ_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_QUARTZ_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_QUARTZ_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_QUARTZ_BRICK_WALL);
        addDrop(ModBlocks.MOSSY_QUARTZ_BRICKS);
        addDrop(ModBlocks.MOSSY_QUARTZ_BRICK_STAIRS);
        addDrop(ModBlocks.MOSSY_QUARTZ_BRICK_SLAB, slabDrops(ModBlocks.MOSSY_QUARTZ_BRICK_SLAB));
        addDrop(ModBlocks.MOSSY_QUARTZ_BRICK_WALL);

        addDrop(ModBlocks.CRACKED_BRICKS);
        addDrop(ModBlocks.CRACKED_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_BRICK_WALL);
        addDrop(ModBlocks.MOSSY_BRICKS);
        addDrop(ModBlocks.MOSSY_BRICK_STAIRS);
        addDrop(ModBlocks.MOSSY_BRICK_SLAB, slabDrops(ModBlocks.MOSSY_BRICK_SLAB));
        addDrop(ModBlocks.MOSSY_BRICK_WALL);
        addDrop(ModBlocks.CHISELED_BRICKS);

        addDrop(ModBlocks.PACKED_MUD_STAIRS);
        addDrop(ModBlocks.PACKED_MUD_SLAB, slabDrops(ModBlocks.PACKED_MUD_SLAB));
        addDrop(ModBlocks.PACKED_MUD_WALL);
        addDrop(ModBlocks.CRACKED_MUD_BRICKS);
        addDrop(ModBlocks.CRACKED_MUD_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_MUD_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_MUD_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_MUD_BRICK_WALL);
        addDrop(ModBlocks.MOSSY_MUD_BRICKS);
        addDrop(ModBlocks.MOSSY_MUD_BRICK_STAIRS);
        addDrop(ModBlocks.MOSSY_MUD_BRICK_SLAB, slabDrops(ModBlocks.MOSSY_MUD_BRICK_SLAB));
        addDrop(ModBlocks.MOSSY_MUD_BRICK_WALL);
        addDrop(ModBlocks.CHISELED_MUD_BRICKS);
        addDrop(ModBlocks.MUD_BRICK_PILLAR);

        addDrop(ModBlocks.SMOOTH_SANDSTONE_WALL);
        addDrop(ModBlocks.CUT_SANDSTONE_STAIRS);
        addDrop(ModBlocks.CUT_SANDSTONE_WALL);
        addDrop(ModBlocks.SANDSTONE_BRICKS);
        addDrop(ModBlocks.SANDSTONE_BRICK_STAIRS);
        addDrop(ModBlocks.SANDSTONE_BRICK_SLAB, slabDrops(ModBlocks.SANDSTONE_BRICK_SLAB));
        addDrop(ModBlocks.SANDSTONE_BRICK_WALL);
        addDrop(ModBlocks.CRACKED_SANDSTONE_BRICKS);
        addDrop(ModBlocks.CRACKED_SANDSTONE_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_SANDSTONE_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_SANDSTONE_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_SANDSTONE_BRICK_WALL);
        addDrop(ModBlocks.MOSSY_SANDSTONE_BRICKS);
        addDrop(ModBlocks.MOSSY_SANDSTONE_BRICK_STAIRS);
        addDrop(ModBlocks.MOSSY_SANDSTONE_BRICK_SLAB, slabDrops(ModBlocks.MOSSY_SANDSTONE_BRICK_SLAB));
        addDrop(ModBlocks.MOSSY_SANDSTONE_BRICK_WALL);
        addDrop(ModBlocks.SANDSTONE_BRICK_PILLAR);

        addDrop(ModBlocks.SMOOTH_RED_SANDSTONE_WALL);
        addDrop(ModBlocks.CUT_RED_SANDSTONE_STAIRS);
        addDrop(ModBlocks.CUT_RED_SANDSTONE_WALL);
        addDrop(ModBlocks.RED_SANDSTONE_BRICKS);
        addDrop(ModBlocks.RED_SANDSTONE_BRICK_STAIRS);
        addDrop(ModBlocks.RED_SANDSTONE_BRICK_SLAB, slabDrops(ModBlocks.RED_SANDSTONE_BRICK_SLAB));
        addDrop(ModBlocks.RED_SANDSTONE_BRICK_WALL);
        addDrop(ModBlocks.CRACKED_RED_SANDSTONE_BRICKS);
        addDrop(ModBlocks.CRACKED_RED_SANDSTONE_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_RED_SANDSTONE_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_RED_SANDSTONE_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_RED_SANDSTONE_BRICK_WALL);
        addDrop(ModBlocks.MOSSY_RED_SANDSTONE_BRICKS);
        addDrop(ModBlocks.MOSSY_RED_SANDSTONE_BRICK_STAIRS);
        addDrop(ModBlocks.MOSSY_RED_SANDSTONE_BRICK_SLAB, slabDrops(ModBlocks.MOSSY_RED_SANDSTONE_BRICK_SLAB));
        addDrop(ModBlocks.MOSSY_RED_SANDSTONE_BRICK_WALL);
        addDrop(ModBlocks.RED_SANDSTONE_BRICK_PILLAR);

        addDrop(ModBlocks.END_STONE_STAIRS);
        addDrop(ModBlocks.END_STONE_SLAB, slabDrops(ModBlocks.END_STONE_SLAB));
        addDrop(ModBlocks.END_STONE_WALL);
        addDrop(ModBlocks.POLISHED_END_STONE);
        addDrop(ModBlocks.POLISHED_END_STONE_STAIRS);
        addDrop(ModBlocks.POLISHED_END_STONE_SLAB, slabDrops(ModBlocks.POLISHED_END_STONE_SLAB));
        addDrop(ModBlocks.POLISHED_END_STONE_WALL);
        addDrop(ModBlocks.CRACKED_END_STONE_BRICKS);
        addDrop(ModBlocks.CRACKED_END_STONE_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_END_STONE_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_END_STONE_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_END_STONE_BRICK_WALL);
        addDrop(ModBlocks.MOSSY_END_STONE_BRICKS);
        addDrop(ModBlocks.MOSSY_END_STONE_BRICK_STAIRS);
        addDrop(ModBlocks.MOSSY_END_STONE_BRICK_SLAB, slabDrops(ModBlocks.MOSSY_END_STONE_BRICK_SLAB));
        addDrop(ModBlocks.MOSSY_END_STONE_BRICK_WALL);
        addDrop(ModBlocks.CHISELED_END_STONE_BRICKS);
        addDrop(ModBlocks.END_STONE_BRICK_PILLAR);

        addDrop(ModBlocks.STONE_WALL);
        addDrop(ModBlocks.SMOOTH_STONE_STAIRS);
        addDrop(ModBlocks.SMOOTH_STONE_WALL);
        addDrop(ModBlocks.CRACKED_STONE_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_STONE_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_STONE_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_STONE_BRICK_WALL);
        addDrop(ModBlocks.STONE_TILES);
        addDrop(ModBlocks.STONE_TILE_STAIRS);
        addDrop(ModBlocks.STONE_TILE_SLAB, slabDrops(ModBlocks.STONE_TILE_SLAB));
        addDrop(ModBlocks.STONE_TILE_WALL);
        addDrop(ModBlocks.CRACKED_STONE_TILES);
        addDrop(ModBlocks.CRACKED_STONE_TILE_STAIRS);
        addDrop(ModBlocks.CRACKED_STONE_TILE_SLAB, slabDrops(ModBlocks.CRACKED_STONE_TILE_SLAB));
        addDrop(ModBlocks.CRACKED_STONE_TILE_WALL);
        addDrop(ModBlocks.MOSSY_STONE_TILES);
        addDrop(ModBlocks.MOSSY_STONE_TILE_STAIRS);
        addDrop(ModBlocks.MOSSY_STONE_TILE_SLAB, slabDrops(ModBlocks.MOSSY_STONE_TILE_SLAB));
        addDrop(ModBlocks.MOSSY_STONE_TILE_WALL);
        addDrop(ModBlocks.STONE_BRICK_PILLAR);

        addDrop(ModBlocks.DEEPSLATE_STAIRS);
        addDrop(ModBlocks.DEEPSLATE_SLAB, slabDrops(ModBlocks.DEEPSLATE_SLAB));
        addDrop(ModBlocks.DEEPSLATE_WALL);
        addDrop(ModBlocks.MOSSY_COBBLED_DEEPSLATE);
        addDrop(ModBlocks.MOSSY_COBBLED_DEEPSLATE_STAIRS);
        addDrop(ModBlocks.MOSSY_COBBLED_DEEPSLATE_SLAB, slabDrops(ModBlocks.MOSSY_COBBLED_DEEPSLATE_SLAB));
        addDrop(ModBlocks.MOSSY_COBBLED_DEEPSLATE_WALL);
        addDrop(ModBlocks.CRACKED_DEEPSLATE_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_DEEPSLATE_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_DEEPSLATE_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_DEEPSLATE_BRICK_WALL);
        addDrop(ModBlocks.MOSSY_DEEPSLATE_BRICKS);
        addDrop(ModBlocks.MOSSY_DEEPSLATE_BRICK_STAIRS);
        addDrop(ModBlocks.MOSSY_DEEPSLATE_BRICK_SLAB, slabDrops(ModBlocks.MOSSY_DEEPSLATE_BRICK_SLAB));
        addDrop(ModBlocks.MOSSY_DEEPSLATE_BRICK_WALL);
        addDrop(ModBlocks.CRACKED_DEEPSLATE_TILE_STAIRS);
        addDrop(ModBlocks.CRACKED_DEEPSLATE_TILE_SLAB, slabDrops(ModBlocks.CRACKED_DEEPSLATE_TILE_SLAB));
        addDrop(ModBlocks.CRACKED_DEEPSLATE_TILE_WALL);
        addDrop(ModBlocks.MOSSY_DEEPSLATE_TILES);
        addDrop(ModBlocks.MOSSY_DEEPSLATE_TILE_STAIRS);
        addDrop(ModBlocks.MOSSY_DEEPSLATE_TILE_SLAB, slabDrops(ModBlocks.MOSSY_DEEPSLATE_TILE_SLAB));
        addDrop(ModBlocks.MOSSY_DEEPSLATE_TILE_WALL);
        addDrop(ModBlocks.DEEPSLATE_BRICK_PILLAR);
        addDropWithSilkTouch(ModBlocks.SCULK_INLAID_DEEPSLATE);
        addDrop(ModBlocks.POLISHED_DEEPSLATE_PRESSURE_PLATE);
        addDrop(ModBlocks.POLISHED_DEEPSLATE_BUTTON);
        
        addDrop(ModBlocks.CRACKED_POLISHED_BLACKSTONE_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_POLISHED_BLACKSTONE_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_POLISHED_BLACKSTONE_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_POLISHED_BLACKSTONE_BRICK_WALL);
        addDrop(ModBlocks.BLACKSTONE_TILES);
        addDrop(ModBlocks.BLACKSTONE_TILE_STAIRS);
        addDrop(ModBlocks.BLACKSTONE_TILE_SLAB, slabDrops(ModBlocks.BLACKSTONE_TILE_SLAB));
        addDrop(ModBlocks.BLACKSTONE_TILE_WALL);
        addDrop(ModBlocks.CRACKED_BLACKSTONE_TILES);
        addDrop(ModBlocks.CRACKED_BLACKSTONE_TILE_STAIRS);
        addDrop(ModBlocks.CRACKED_BLACKSTONE_TILE_SLAB, slabDrops(ModBlocks.CRACKED_BLACKSTONE_TILE_SLAB));
        addDrop(ModBlocks.CRACKED_BLACKSTONE_TILE_WALL);
        addDrop(ModBlocks.BLACKSTONE_BRICK_PILLAR);

        addDrop(ModBlocks.NETHERRACK_STAIRS);
        addDrop(ModBlocks.NETHERRACK_SLAB, slabDrops(ModBlocks.NETHERRACK_SLAB));
        addDrop(ModBlocks.NETHERRACK_WALL);

        this.addDrop(ModBlocks.SNOW_BRICKS,
                this.dropsWithSilkTouch(ModBlocks.SNOW_BRICKS,
                        ItemEntry.builder(Items.SNOWBALL)
                                .apply(SetCountLootFunction.builder(ConstantLootNumberProvider.create(4)))
                                .apply(ExplosionDecayLootFunction.builder())
                )
        );
        this.addDrop(ModBlocks.SNOW_BRICK_STAIRS,
                this.dropsWithSilkTouch(ModBlocks.SNOW_BRICK_STAIRS,
                        ItemEntry.builder(Items.SNOWBALL)
                                .apply(SetCountLootFunction.builder(ConstantLootNumberProvider.create(4)))
                                .apply(ExplosionDecayLootFunction.builder())
                )
        );
        this.addDrop(ModBlocks.SNOW_BRICK_SLAB,
                LootTable.builder().pool(LootPool.builder()
                        .rolls(ConstantLootNumberProvider.create(1))
                        .with(ItemEntry.builder(ModBlocks.SNOW_BRICK_SLAB)
                                .conditionally(this.createSilkTouchCondition())
                                .conditionally(BlockStatePropertyLootCondition.builder(ModBlocks.SNOW_BRICK_SLAB)
                                        .properties(net.minecraft.predicate.StatePredicate.Builder.create()
                                                .exactMatch(SlabBlock.TYPE, SlabType.DOUBLE)))
                                .apply(SetCountLootFunction.builder(ConstantLootNumberProvider.create(2)))

                                .alternatively(ItemEntry.builder(ModBlocks.SNOW_BRICK_SLAB)
                                        .conditionally(this.createSilkTouchCondition()))

                                .alternatively(ItemEntry.builder(Items.SNOWBALL)
                                        .conditionally(this.createWithoutSilkTouchCondition())
                                        .conditionally(BlockStatePropertyLootCondition.builder(ModBlocks.SNOW_BRICK_SLAB)
                                                .properties(net.minecraft.predicate.StatePredicate.Builder.create()
                                                        .exactMatch(SlabBlock.TYPE, SlabType.DOUBLE)))
                                        .apply(SetCountLootFunction.builder(ConstantLootNumberProvider.create(4)))
                                        .apply(ExplosionDecayLootFunction.builder())
                                )

                                .alternatively(ItemEntry.builder(Items.SNOWBALL)
                                        .conditionally(this.createWithoutSilkTouchCondition())
                                        .apply(SetCountLootFunction.builder(ConstantLootNumberProvider.create(2)))
                                        .apply(ExplosionDecayLootFunction.builder())
                                )
                        )
                )
        );
        this.addDrop(ModBlocks.SNOW_BRICK_WALL,
                this.dropsWithSilkTouch(ModBlocks.SNOW_BRICK_WALL,
                        ItemEntry.builder(Items.SNOWBALL)
                                .apply(SetCountLootFunction.builder(ConstantLootNumberProvider.create(4)))
                                .apply(ExplosionDecayLootFunction.builder())
                )
        );

        addDrop(ModBlocks.CRACKED_NETHER_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_NETHER_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_NETHER_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_NETHER_BRICK_WALL);
        addDrop(ModBlocks.CRACKED_NETHER_BRICK_FENCE);

        addDrop(ModBlocks.RED_NETHER_BRICK_FENCE);
        addDrop(ModBlocks.CRACKED_RED_NETHER_BRICKS);
        addDrop(ModBlocks.CRACKED_RED_NETHER_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_RED_NETHER_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_RED_NETHER_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_RED_NETHER_BRICK_WALL);
        addDrop(ModBlocks.CRACKED_RED_NETHER_BRICK_FENCE);
        addDrop(ModBlocks.CHISELED_RED_NETHER_BRICKS);

        addDrop(ModBlocks.BLUE_NETHER_BRICKS);
        addDrop(ModBlocks.BLUE_NETHER_BRICK_STAIRS);
        addDrop(ModBlocks.BLUE_NETHER_BRICK_SLAB, slabDrops(ModBlocks.BLUE_NETHER_BRICK_SLAB));
        addDrop(ModBlocks.BLUE_NETHER_BRICK_WALL);
        addDrop(ModBlocks.BLUE_NETHER_BRICK_FENCE);
        addDrop(ModBlocks.CRACKED_BLUE_NETHER_BRICKS);
        addDrop(ModBlocks.CRACKED_BLUE_NETHER_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_BLUE_NETHER_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_BLUE_NETHER_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_BLUE_NETHER_BRICK_WALL);
        addDrop(ModBlocks.CRACKED_BLUE_NETHER_BRICK_FENCE);
        addDrop(ModBlocks.CHISELED_BLUE_NETHER_BRICKS);

        addDrop(ModBlocks.PRISMARINE_BRICK_WALL);
        addDrop(ModBlocks.DARK_PRISMARINE_WALL);
        addDrop(ModBlocks.CRACKED_PRISMARINE_BRICKS);
        addDrop(ModBlocks.CRACKED_PRISMARINE_BRICK_STAIRS);
        addDrop(ModBlocks.CRACKED_PRISMARINE_BRICK_SLAB, slabDrops(ModBlocks.CRACKED_PRISMARINE_BRICK_SLAB));
        addDrop(ModBlocks.CRACKED_PRISMARINE_BRICK_WALL);
        addDrop(ModBlocks.MOSSY_PRISMARINE_BRICKS);
        addDrop(ModBlocks.MOSSY_PRISMARINE_BRICK_STAIRS);
        addDrop(ModBlocks.MOSSY_PRISMARINE_BRICK_SLAB, slabDrops(ModBlocks.MOSSY_PRISMARINE_BRICK_SLAB));
        addDrop(ModBlocks.MOSSY_PRISMARINE_BRICK_WALL);
        addDrop(ModBlocks.CHISELED_PRISMARINE_BRICKS);
        addDrop(ModBlocks.PRISMARINE_BRICK_PILLAR);

        addDrop(ModBlocks.SMOOTH_BASALT_STAIRS);
        addDrop(ModBlocks.SMOOTH_BASALT_SLAB, slabDrops(ModBlocks.SMOOTH_BASALT_SLAB));
        addDrop(ModBlocks.SMOOTH_BASALT_WALL);

        addDrop(ModBlocks.PURPUR_WALL);
        addDrop(ModBlocks.CHISELED_PURPUR);

        addDropWithSilkTouch(ModBlocks.TINTED_GLASS_PANE);

        addDrop(ModBlocks.TERRACOTTA_STAIRS);
        addDrop(ModBlocks.TERRACOTTA_SLAB, slabDrops(ModBlocks.TERRACOTTA_SLAB));
        addDrop(ModBlocks.TERRACOTTA_WALL);
        addDrop(ModBlocks.WHITE_TERRACOTTA_STAIRS);
        addDrop(ModBlocks.WHITE_TERRACOTTA_SLAB, slabDrops(ModBlocks.WHITE_TERRACOTTA_SLAB));
        addDrop(ModBlocks.WHITE_TERRACOTTA_WALL);
        addDrop(ModBlocks.LIGHT_GRAY_TERRACOTTA_STAIRS);
        addDrop(ModBlocks.LIGHT_GRAY_TERRACOTTA_SLAB, slabDrops(ModBlocks.LIGHT_GRAY_TERRACOTTA_SLAB));
        addDrop(ModBlocks.LIGHT_GRAY_TERRACOTTA_WALL);
        addDrop(ModBlocks.GRAY_TERRACOTTA_STAIRS);
        addDrop(ModBlocks.GRAY_TERRACOTTA_SLAB, slabDrops(ModBlocks.GRAY_TERRACOTTA_SLAB));
        addDrop(ModBlocks.GRAY_TERRACOTTA_WALL);
        addDrop(ModBlocks.BLACK_TERRACOTTA_STAIRS);
        addDrop(ModBlocks.BLACK_TERRACOTTA_SLAB, slabDrops(ModBlocks.BLACK_TERRACOTTA_SLAB));
        addDrop(ModBlocks.BLACK_TERRACOTTA_WALL);
        addDrop(ModBlocks.BROWN_TERRACOTTA_STAIRS);
        addDrop(ModBlocks.BROWN_TERRACOTTA_SLAB, slabDrops(ModBlocks.BROWN_TERRACOTTA_SLAB));
        addDrop(ModBlocks.BROWN_TERRACOTTA_WALL);
        addDrop(ModBlocks.RED_TERRACOTTA_STAIRS);
        addDrop(ModBlocks.RED_TERRACOTTA_SLAB, slabDrops(ModBlocks.RED_TERRACOTTA_SLAB));
        addDrop(ModBlocks.RED_TERRACOTTA_WALL);
        addDrop(ModBlocks.ORANGE_TERRACOTTA_STAIRS);
        addDrop(ModBlocks.ORANGE_TERRACOTTA_SLAB, slabDrops(ModBlocks.ORANGE_TERRACOTTA_SLAB));
        addDrop(ModBlocks.ORANGE_TERRACOTTA_WALL);
        addDrop(ModBlocks.YELLOW_TERRACOTTA_STAIRS);
        addDrop(ModBlocks.YELLOW_TERRACOTTA_SLAB, slabDrops(ModBlocks.YELLOW_TERRACOTTA_SLAB));
        addDrop(ModBlocks.YELLOW_TERRACOTTA_WALL);
        addDrop(ModBlocks.LIME_TERRACOTTA_STAIRS);
        addDrop(ModBlocks.LIME_TERRACOTTA_SLAB, slabDrops(ModBlocks.LIME_TERRACOTTA_SLAB));
        addDrop(ModBlocks.LIME_TERRACOTTA_WALL);
        addDrop(ModBlocks.GREEN_TERRACOTTA_STAIRS);
        addDrop(ModBlocks.GREEN_TERRACOTTA_SLAB, slabDrops(ModBlocks.GREEN_TERRACOTTA_SLAB));
        addDrop(ModBlocks.GREEN_TERRACOTTA_WALL);
        addDrop(ModBlocks.CYAN_TERRACOTTA_STAIRS);
        addDrop(ModBlocks.CYAN_TERRACOTTA_SLAB, slabDrops(ModBlocks.CYAN_TERRACOTTA_SLAB));
        addDrop(ModBlocks.CYAN_TERRACOTTA_WALL);
        addDrop(ModBlocks.LIGHT_BLUE_TERRACOTTA_STAIRS);
        addDrop(ModBlocks.LIGHT_BLUE_TERRACOTTA_SLAB, slabDrops(ModBlocks.LIGHT_BLUE_TERRACOTTA_SLAB));
        addDrop(ModBlocks.LIGHT_BLUE_TERRACOTTA_WALL);
        addDrop(ModBlocks.BLUE_TERRACOTTA_STAIRS);
        addDrop(ModBlocks.BLUE_TERRACOTTA_SLAB, slabDrops(ModBlocks.BLUE_TERRACOTTA_SLAB));
        addDrop(ModBlocks.BLUE_TERRACOTTA_WALL);
        addDrop(ModBlocks.PURPLE_TERRACOTTA_STAIRS);
        addDrop(ModBlocks.PURPLE_TERRACOTTA_SLAB, slabDrops(ModBlocks.PURPLE_TERRACOTTA_SLAB));
        addDrop(ModBlocks.PURPLE_TERRACOTTA_WALL);
        addDrop(ModBlocks.MAGENTA_TERRACOTTA_STAIRS);
        addDrop(ModBlocks.MAGENTA_TERRACOTTA_SLAB, slabDrops(ModBlocks.MAGENTA_TERRACOTTA_SLAB));
        addDrop(ModBlocks.MAGENTA_TERRACOTTA_WALL);
        addDrop(ModBlocks.PINK_TERRACOTTA_STAIRS);
        addDrop(ModBlocks.PINK_TERRACOTTA_SLAB, slabDrops(ModBlocks.PINK_TERRACOTTA_SLAB));
        addDrop(ModBlocks.PINK_TERRACOTTA_WALL);

        addDrop(ModBlocks.WHITE_CONCRETE_STAIRS);
        addDrop(ModBlocks.WHITE_CONCRETE_SLAB, slabDrops(ModBlocks.WHITE_CONCRETE_SLAB));
        addDrop(ModBlocks.WHITE_CONCRETE_WALL);
        addDrop(ModBlocks.LIGHT_GRAY_CONCRETE_STAIRS);
        addDrop(ModBlocks.LIGHT_GRAY_CONCRETE_SLAB, slabDrops(ModBlocks.LIGHT_GRAY_CONCRETE_SLAB));
        addDrop(ModBlocks.LIGHT_GRAY_CONCRETE_WALL);
        addDrop(ModBlocks.GRAY_CONCRETE_STAIRS);
        addDrop(ModBlocks.GRAY_CONCRETE_SLAB, slabDrops(ModBlocks.GRAY_CONCRETE_SLAB));
        addDrop(ModBlocks.GRAY_CONCRETE_WALL);
        addDrop(ModBlocks.BLACK_CONCRETE_STAIRS);
        addDrop(ModBlocks.BLACK_CONCRETE_SLAB, slabDrops(ModBlocks.BLACK_CONCRETE_SLAB));
        addDrop(ModBlocks.BLACK_CONCRETE_WALL);
        addDrop(ModBlocks.BROWN_CONCRETE_STAIRS);
        addDrop(ModBlocks.BROWN_CONCRETE_SLAB, slabDrops(ModBlocks.BROWN_CONCRETE_SLAB));
        addDrop(ModBlocks.BROWN_CONCRETE_WALL);
        addDrop(ModBlocks.RED_CONCRETE_STAIRS);
        addDrop(ModBlocks.RED_CONCRETE_SLAB, slabDrops(ModBlocks.RED_CONCRETE_SLAB));
        addDrop(ModBlocks.RED_CONCRETE_WALL);
        addDrop(ModBlocks.ORANGE_CONCRETE_STAIRS);
        addDrop(ModBlocks.ORANGE_CONCRETE_SLAB, slabDrops(ModBlocks.ORANGE_CONCRETE_SLAB));
        addDrop(ModBlocks.ORANGE_CONCRETE_WALL);
        addDrop(ModBlocks.YELLOW_CONCRETE_STAIRS);
        addDrop(ModBlocks.YELLOW_CONCRETE_SLAB, slabDrops(ModBlocks.YELLOW_CONCRETE_SLAB));
        addDrop(ModBlocks.YELLOW_CONCRETE_WALL);
        addDrop(ModBlocks.LIME_CONCRETE_STAIRS);
        addDrop(ModBlocks.LIME_CONCRETE_SLAB, slabDrops(ModBlocks.LIME_CONCRETE_SLAB));
        addDrop(ModBlocks.LIME_CONCRETE_WALL);
        addDrop(ModBlocks.GREEN_CONCRETE_STAIRS);
        addDrop(ModBlocks.GREEN_CONCRETE_SLAB, slabDrops(ModBlocks.GREEN_CONCRETE_SLAB));
        addDrop(ModBlocks.GREEN_CONCRETE_WALL);
        addDrop(ModBlocks.CYAN_CONCRETE_STAIRS);
        addDrop(ModBlocks.CYAN_CONCRETE_SLAB, slabDrops(ModBlocks.CYAN_CONCRETE_SLAB));
        addDrop(ModBlocks.CYAN_CONCRETE_WALL);
        addDrop(ModBlocks.LIGHT_BLUE_CONCRETE_STAIRS);
        addDrop(ModBlocks.LIGHT_BLUE_CONCRETE_SLAB, slabDrops(ModBlocks.LIGHT_BLUE_CONCRETE_SLAB));
        addDrop(ModBlocks.LIGHT_BLUE_CONCRETE_WALL);
        addDrop(ModBlocks.BLUE_CONCRETE_STAIRS);
        addDrop(ModBlocks.BLUE_CONCRETE_SLAB, slabDrops(ModBlocks.BLUE_CONCRETE_SLAB));
        addDrop(ModBlocks.BLUE_CONCRETE_WALL);
        addDrop(ModBlocks.PURPLE_CONCRETE_STAIRS);
        addDrop(ModBlocks.PURPLE_CONCRETE_SLAB, slabDrops(ModBlocks.PURPLE_CONCRETE_SLAB));
        addDrop(ModBlocks.PURPLE_CONCRETE_WALL);
        addDrop(ModBlocks.MAGENTA_CONCRETE_STAIRS);
        addDrop(ModBlocks.MAGENTA_CONCRETE_SLAB, slabDrops(ModBlocks.MAGENTA_CONCRETE_SLAB));
        addDrop(ModBlocks.MAGENTA_CONCRETE_WALL);
        addDrop(ModBlocks.PINK_CONCRETE_STAIRS);
        addDrop(ModBlocks.PINK_CONCRETE_SLAB, slabDrops(ModBlocks.PINK_CONCRETE_SLAB));
        addDrop(ModBlocks.PINK_CONCRETE_WALL);
    }
}